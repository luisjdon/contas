<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Financeiro </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Botão para abrir o chat -->
<button onclick="abrirChat()" class="btn btn-primary" style="position: fixed; bottom: 20px; right: 20px;">
    💬 Registrar Transação
</button>

<!-- Popup de Chat -->
<div id="chat-popup" style="display: none; position: fixed; bottom: 20px; right: 20px; width: 350px; background: #fff;
    border: 2px solid #ccc; box-shadow: 0 0 10px rgba(0,0,0,0.2); border-radius: 8px;">
    <div style="background: #007bff; color: white; padding: 10px; font-weight: bold; display: flex; justify-content: space-between;">
        💰 Gemini FinanceBot
        <button onclick="fecharChat()">✖</button>
    </div>
    <div style="padding: 10px;">
        <div id="chat-messages"></div>
        <input type="text" id="chat-input" class="form-control mt-2" placeholder="Ex: Gastei 50 reais com comida" />
        <button onclick="enviarMensagem()" class="btn btn-success mt-2">Enviar</button>
    </div>
</div>

<!-- JavaScript para controle do chat -->
<script>
function abrirChat() {
    document.getElementById("chat-popup").style.display = "block";
}

function fecharChat() {
    document.getElementById("chat-popup").style.display = "none";
}

async function enviarMensagem() {
    const userText = document.getElementById("chat-input").value;
    document.getElementById("chat-messages").innerHTML += `<p><strong>Você:</strong> ${userText}</p>`;

    const response = await fetch('processar_gemini.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: userText })
    });

    const data = await response.json();
    document.getElementById("chat-messages").innerHTML += `<p><strong>Gemini:</strong> ${data.message}</p>`;
}
</script>

</body>
</html>