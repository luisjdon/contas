<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Página de relatórios
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Obter relatórios ou dados de transações
$sql = "SELECT t.id, t.data, t.valor, t.descricao, c.nome AS categoria
        FROM transacoes t
        LEFT JOIN categorias c ON t.categoria_id = c.id
        ORDER BY t.data DESC";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
$transacoes = $result->fetch_all(MYSQLI_ASSOC);

// Inclui o cabeçalho
include 'includes/header.php';

// Exibe os relatórios
?>

<div class="container mt-4">
    <h2>Relatórios de Transações</h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Data</th>
                <th>Descrição</th>
                <th>Valor</th>
                <th>Categoria</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($transacoes as $transacao): ?>
            <tr>
                <td><?php echo date('d/m/Y', strtotime($transacao['data'])); ?></td>
                <td><?php echo !empty($transacao['descricao']) ? htmlspecialchars($transacao['descricao']) : 'Sem descrição'; ?></td>
                <td><?php echo number_format($transacao['valor'], 2, ',', '.'); ?></td>
                <td><?php echo !empty($transacao['categoria']) ? htmlspecialchars($transacao['categoria']) : 'Sem categoria'; ?></td>
                <td>
                    <!-- Ações, como editar ou excluir -->
                    <a href="edit_transaction.php?id=<?php echo $transacao['id']; ?>" class="btn btn-warning btn-sm">Editar</a>
                    <a href="delete_transaction.php?id=<?php echo $transacao['id']; ?>" class="btn btn-danger btn-sm">Excluir</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
// Inclui o rodapé
include 'includes/footer.php';
?>