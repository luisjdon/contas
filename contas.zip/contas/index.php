<?php
// Página de login
$page_title = "Login";
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// Redireciona para o dashboard se já estiver logado
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

// Processamento do formulário de login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize($conn, $_POST['email']);
    $senha = $_POST['senha'];
    
    // Validação básica
    if (empty($email) || empty($senha)) {
        $error = 'Por favor, preencha todos os campos.';
    } else {
        // Tenta fazer login
        $resultado = login_user($conn, $email, $senha);
        
        if ($resultado['success']) {
            // Login bem-sucedido, redireciona para o dashboard
            header('Location: dashboard.php');
            exit;
        } else {
            $error = $resultado['message'];
        }
    }
}

// Inclui o cabeçalho
include 'includes/header.php';
?>

<!-- Adicionando a referência ao CSS -->
<head>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h2 class="mb-0">Login</h2>
            </div>
            <div class="card-body">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="senha" name="senha" required>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Entrar</button>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center">
                <p class="mb-0">Não tem uma conta? <a href="register.php">Cadastre-se</a></p>
            </div>
        </div>
    </div>
</div>

<?php
// Inclui o rodapé
include 'includes/footer.php';
?>
