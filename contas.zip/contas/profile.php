<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Verifique se a conexão foi realizada corretamente
if (!$conn) {
    die('Falha na conexão com o banco de dados: ' . mysqli_connect_error());
}

// Busca as informações do perfil do usuário
$sql = "SELECT nome, email, data_nascimento, foto_perfil FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Erro no prepare: ' . $conn->error);
}
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Verifica se há uma atualização do perfil
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $data_nascimento = $_POST['data_nascimento'];
    
    // Verifica se o usuário enviou uma foto de perfil
    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == UPLOAD_ERR_OK) {
        $foto_nome = $_FILES['foto_perfil']['name'];
        $foto_temp = $_FILES['foto_perfil']['tmp_name'];
        $foto_dir = 'uploads/' . $foto_nome;

        if (!move_uploaded_file($foto_temp, $foto_dir)) {
            die('Erro ao mover o arquivo de imagem.');
        }
    } else {
        $foto_dir = $user['foto_perfil'];
    }
    
    // Atualiza as informações no banco
    $update_sql = "UPDATE usuarios SET nome = ?, email = ?, data_nascimento = ?, foto_perfil = ? WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param('ssssi', $nome, $email, $data_nascimento, $foto_dir, $_SESSION['user_id']);
    if ($update_stmt->execute()) {
        header('Location: profile.php');
        exit;
    } else {
        die('Erro ao atualizar o perfil: ' . $update_stmt->error);
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<div class="container">
    <h1>Perfil do Usuário</h1>
    <form action="profile.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" value="<?php echo $user['nome']; ?>" required>
        </div>

        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>
        </div>

        <div class="form-group">
            <label for="data_nascimento">Data de Nascimento</label>
            <input type="date" id="data_nascimento" name="data_nascimento" value="<?php echo $user['data_nascimento']; ?>" required>
        </div>

        <div class="form-group">
            <label for="foto_perfil">Foto de Perfil</label>
            <input type="file" id="foto_perfil" name="foto_perfil">
            <?php if ($user['foto_perfil']) : ?>
                <img src="<?php echo $user['foto_perfil']; ?>" alt="Foto de Perfil" width="100">
            <?php endif; ?>
        </div>

        <button type="submit">Salvar alterações</button>
    </form>
</div>

<?php include 'includes/footer.php'; ?>

</body>
</html>
