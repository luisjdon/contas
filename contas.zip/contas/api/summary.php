<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['error' => 'Usuário não autenticado']);
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT type, category, amount FROM transactions WHERE user_id = ?");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_income = 0;
$total_expense = 0;
$categories = [];

foreach ($transactions as $t) {
    $amount = floatval($t['amount']);
    if ($t['type'] === 'receita') {
        $total_income += $amount;
    } else {
        $total_expense += $amount;
        $cat = $t['category'];
        if (!isset($categories[$cat])) $categories[$cat] = 0;
        $categories[$cat] += $amount;
    }
}

arsort($categories);
$top_categories = array_slice($categories, 0, 3);

$prompt = "Dados financeiros do casal:\n";
$prompt .= "- Receita total: R$ " . number_format($total_income, 2, ',', '.') . "\n";
$prompt .= "- Despesas totais: R$ " . number_format($total_expense, 2, ',', '.') . "\n";
$prompt .= "- Categorias mais gastas: ";
foreach ($top_categories as $cat => $val) {
    $prompt .= "$cat (R$ " . number_format($val, 2, ',', '.') . "), ";
}
$prompt = rtrim($prompt, ', ') . "\n";
$prompt .= "Gere um insight financeiro simples e últil para o casal.";

$api_key = "AIzaSyA8ddEupbrglm7N2kjpNCtKimssaWUqKeg";
$url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=$api_key";

$payload = [
    "contents" => [[
        "parts" => [[ "text" => $prompt ]]
    ]]
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);

if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
    echo json_encode([
        'insight' => $data['candidates'][0]['content']['parts'][0]['text']
    ]);
} else {
    echo json_encode([
        'error' => 'Erro ao gerar insight com Gemini.'
    ]);
}
