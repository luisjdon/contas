<?php
header('Content-Type: application/json');
require_once '../includes/auth.php';

$api_key = "AIzaSyAhtSTUL7Rz5ex1D_fEA6Gg77FiiBOdQDw"; // Substitua por sua chave válida

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);

    if (!isset($input['data'])) {
        echo json_encode(['success' => false, 'message' => 'Dados financeiros não fornecidos.']);
        exit;
    }

    // Construir um prompt adequado para o Gemini AI
    $financialData = $input['data'];
    $userText = "Com base nos seguintes dados financeiros: Receita mensal: {$financialData['receita_mensal']}, 
    Despesa mensal: {$financialData['despesa_mensal']}, Saldo mensal: {$financialData['saldo_mensal']}, 
    Histórico dos últimos meses: " . json_encode($financialData['historico']) . ", 
    Categorias de despesas: " . json_encode($financialData['categorias']) . 
    ", forneça insights financeiros para melhorar a gestão do dinheiro.";

    $payload = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $userText]
                ]
            ]
        ]
    ];

    // Definir o modelo correto (gemini-1.5-flash)
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $api_key);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    // Depuração para verificar erro na resposta da API
    error_log(print_r($result, true));

    if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
        $insight = $result['candidates'][0]['content']['parts'][0]['text'];
        echo json_encode([
            'success' => true,
            'insights' => nl2br($insight)
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Não foi possível obter resposta da IA.',
            'debug' => $result
        ]);
    }
}