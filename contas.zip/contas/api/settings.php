<?php
// API para gerenciar configurações do usuário
header('Content-Type: application/json');
include('../includes/config.php');
include('../includes/functions.php');
include('../includes/auth.php');

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Usuário não autenticado.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Função para obter configurações do usuário
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Recupera configurações do usuário
    $sql = "SELECT * FROM configuracoes WHERE usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $configuracoes = $result->fetch_assoc();
    echo json_encode($configuracoes);
}

// Função para atualizar configurações do usuário
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dados = json_decode(file_get_contents('php://input'), true);

    // Atualiza configurações
    $sql = "UPDATE configuracoes SET parametro = ? WHERE usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $dados['parametro'], $user_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Erro ao atualizar configurações.']);
    }
}
