<?php
// API para gerenciar categorias de transações
header('Content-Type: application/json');
include('../includes/config.php');
include('../includes/functions.php');
include('../includes/auth.php');

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Usuário não autenticado.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Função para obter categorias
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Recupera categorias do usuário
    $categorias = get_categories($conn, $user_id);
    echo json_encode($categorias);
}

// Função para adicionar ou editar categoria
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dados = json_decode(file_get_contents('php://input'), true);

    // Verifica se o dado contém ID (para edição) ou é uma nova categoria
    if (isset($dados['id'])) {
        $success = save_category($conn, $dados);
        echo json_encode(['success' => $success]);
    } else {
        $dados['usuario_id'] = $user_id;
        $success = save_category($conn, $dados);
        echo json_encode(['success' => $success]);
    }
}

// Função para excluir categoria
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $dados = json_decode(file_get_contents('php://input'), true);
    $id_excluir = intval($dados['id']);
    
    // Exclui categoria
    $sql = "DELETE FROM categorias WHERE id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_excluir, $user_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Erro ao excluir categoria.']);
    }
}
