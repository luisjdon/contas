<?php
// API para gerenciar transações financeiras
header('Content-Type: application/json');
include('../includes/config.php');
include('../includes/functions.php');
include('../includes/auth.php');

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Usuário não autenticado.']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Função para recuperar transações com filtros
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $filtros = [
        'tipo' => $_GET['tipo'] ?? '',
        'categoria_id' => $_GET['categoria_id'] ?? '',
        'data_inicio' => $_GET['data_inicio'] ?? '',
        'data_fim' => $_GET['data_fim'] ?? ''
    ];

    $pagina = isset($_GET['pagina']) ? intval($_GET['pagina']) : 1;
    $por_pagina = 10;

    // Busca transações do usuário com base nos filtros
    $transacoes = get_transactions($conn, $user_id, $pagina, $por_pagina, $filtros);
    echo json_encode($transacoes);
}

// Função para salvar ou atualizar transações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $dados = json_decode(file_get_contents('php://input'), true);
    if (isset($dados['id'])) {
        // Atualizar transação
        $dados['id'] = intval($dados['id']);
        $success = save_transaction($conn, $dados);
        echo json_encode(['success' => $success]);
    } else {
        // Adicionar nova transação
        $dados['usuario_id'] = $user_id;
        $success = save_transaction($conn, $dados);
        echo json_encode(['success' => $success]);
    }
}

// Função para excluir transação
if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    $dados = json_decode(file_get_contents('php://input'), true);
    $id_excluir = intval($dados['id']);
    
    // Excluir transação
    $sql = "DELETE FROM transacoes WHERE id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_excluir, $user_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Erro ao excluir transação.']);
    }
}
