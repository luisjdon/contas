<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
    #chat-popup {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 350px;
        background: #fff;
        border: 2px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        z-index: 9999; /* Garante que o chat ficará acima de todos os elementos */
    }
</style>
</head>
<body>

<!-- Botão para abrir o chat -->


<!-- Popup de Chat -->
<div id="chat-popup" style="display: none; position: fixed; bottom: 20px; right: 20px; width: 350px; background: #fff;
    border: 2px solid #ccc; box-shadow: 0 0 10px rgba(0,0,0,0.2); border-radius: 8px;">
    <div style="background: #007bff; color: white; padding: 10px; font-weight: bold; display: flex; justify-content: space-between;">
        💰  FinanceBot
        <button onclick="fecharChat()">✖</button>
    </div>
    <div style="padding: 10px;">
        <div id="chat-messages"></div>
        <input type="text" id="chat-input" class="form-control mt-2" placeholder="Ex: Gastei 50 reais com comida" />
        <button onclick="enviarMensagem()" class="btn btn-success mt-2">Enviar</button>
    </div>
</div>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Botão para abrir o chat -->
<button onclick="abrirChat()" class="btn btn-primary" style="position: fixed; bottom: 20px; right: 20px;">
    💬 Registrar Transação
</button>

<!-- Popup de Chat -->
<div id="chat-popup" style="display: none; position: fixed; bottom: 20px; right: 20px; width: 350px; background: #fff;
    border: 2px solid #ccc; box-shadow: 0 0 10px rgba(0,0,0,0.2); border-radius: 8px;">
    <div style="background: #007bff; color: white; padding: 10px; font-weight: bold; display: flex; justify-content: space-between;">
        💰 Gemini FinanceBot
        <button onclick="fecharChat()">✖</button>
    </div>
    <div style="padding: 10px;">
        <div id="chat-messages"></div>
        <input type="text" id="chat-input" class="form-control mt-2" placeholder="Ex: Gastei 50 reais com comida" />
        <button onclick="enviarMensagem()" class="btn btn-success mt-2">Enviar</button>
    </div>
</div>

<?php

// Página do Dashboard
$page_title = "Dashboard";
include 'includes/header.php';

// Obtém dados do mês atual e do mês anterior para o saldo
$user_id = $_SESSION['user_id'];
$mes_atual = date('Y-m');
$primeiro_dia = date('Y-m-01');
$ultimo_dia = date('Y-m-t');

// Calcular o mês anterior
$mes_anterior = date('Y-m', strtotime('-1 month'));

// Obter dados financeiros incluindo mês atual e anterior
// Para receitas e despesas do mês atual
$receita_mensal = get_month_revenue($conn, $user_id, $mes_atual);
$despesa_mensal = get_month_expenses($conn, $user_id, $mes_atual);

// Para receitas e despesas do mês anterior que afetam o saldo atual
$receita_mes_anterior = get_month_revenue($conn, $user_id, $mes_anterior);
$despesa_mes_anterior = get_month_expenses($conn, $user_id, $mes_anterior);

// Saldo total considerando mês atual e anterior
$saldo_mensal = ($receita_mensal + $receita_mes_anterior) - ($despesa_mensal + $despesa_mes_anterior);

// Obtém transações recentes
$transacoes_recentes = get_transactions($conn, $user_id, 1, 5);

// Obtém despesas por categoria considerando mês atual e anterior
// Calcular o primeiro dia do mês anterior
$primeiro_dia_mes_anterior = date('Y-m-01', strtotime('-1 month'));

$sql = "SELECT c.nome as categoria, SUM(t.valor) as total
        FROM transacoes t
        JOIN categorias c ON t.categoria_id = c.id
        WHERE t.usuario_id = ? AND t.tipo = 'despesa' AND t.data BETWEEN ? AND ?
        GROUP BY t.categoria_id
        ORDER BY total DESC
        LIMIT 5";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iss", $user_id, $primeiro_dia_mes_anterior, $ultimo_dia);
$stmt->execute();
$result = $stmt->get_result();

$despesas_por_categoria = array();
$categorias_labels = array();
$categorias_valores = array();

while ($row = $result->fetch_assoc()) {
    $despesas_por_categoria[] = $row;
    $categorias_labels[] = $row['categoria'];
    $categorias_valores[] = $row['total'];
}

// Obtém receitas e despesas dos últimos 6 meses
$sql = "SELECT 
          DATE_FORMAT(data, '%Y-%m') as mes, 
          SUM(CASE WHEN tipo = 'receita' THEN valor ELSE 0 END) as receitas,
          SUM(CASE WHEN tipo = 'despesa' THEN valor ELSE 0 END) as despesas
        FROM transacoes
        WHERE usuario_id = ? AND data >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(data, '%Y-%m')
        ORDER BY mes ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$historico_meses = array();
$historico_labels = array();
$historico_receitas = array();
$historico_despesas = array();

while ($row = $result->fetch_assoc()) {
    $historico_meses[] = $row;
    $historico_labels[] = date('M/Y', strtotime($row['mes'] . '-01'));
    $historico_receitas[] = $row['receitas'];
    $historico_despesas[] = $row['despesas'];
}
?>

<div class="container-fluid">
    <!-- Resumo Financeiro -->
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Receitas Acumuladas</h5>
                    <p class="card-text text-success h3"><?php echo format_currency($receita_mensal + $receita_mes_anterior); ?></p>
                    <div class="small text-muted">
                        Mês atual: <?php echo format_currency($receita_mensal); ?><br>
                        Mês anterior: <?php echo format_currency($receita_mes_anterior); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Despesas Acumuladas</h5>
                    <p class="card-text text-danger h3"><?php echo format_currency($despesa_mensal + $despesa_mes_anterior); ?></p>
                    <div class="small text-muted">
                        Mês atual: <?php echo format_currency($despesa_mensal); ?><br>
                        Mês anterior: <?php echo format_currency($despesa_mes_anterior); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Saldo Acumulado</h5>
                    <p class="card-text h3 <?php echo $saldo_mensal >= 0 ? 'text-success' : 'text-danger'; ?>">
                        <?php echo format_currency($saldo_mensal); ?>
                    </p>
                    <div class="small text-muted">
                        Considerando receitas e despesas do mês atual e anterior
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Gráficos e Tabelas -->
    <div class="row mb-4">
        <!-- Gráfico de Despesas por Categoria -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">Despesas Acumuladas por Categoria</h5>
                    <small class="text-muted">Considerando mês atual e anterior</small>
                </div>
                <div class="card-body">
                    <canvas id="despesasPorCategoria"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Gráfico de Receitas x Despesas -->
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">Receitas x Despesas (6 meses)</h5>
                </div>
                <div class="card-body">
                    <canvas id="historicoFinanceiro"></canvas>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Transações Recentes -->
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Transações Recentes</h5>
                    <a href="transactions.php" class="btn btn-sm btn-primary">Ver Todas</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Tipo</th>
                                    <th>Categoria</th>
                                    <th>Valor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($transacoes_recentes)): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">Nenhuma transação encontrada.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($transacoes_recentes as $transacao): ?>
                                        <tr>
                                            <td><?php echo format_date_to_br($transacao['data']); ?></td>
                                            <td>
                                                <?php if ($transacao['tipo'] == 'receita'): ?>
                                                    <span class="badge bg-success">Receita</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Despesa</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($transacao['categoria_nome']); ?></td>
                                            <td class="<?php echo $transacao['tipo'] == 'receita' ? 'text-success' : 'text-danger'; ?>">
                                                <?php echo format_currency($transacao['valor']); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sugestões do Gemini -->
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">Insights Financeiros </h5>
                </div>
                <div class="card-body">
                    <div id="gemini-insights">
                        <div class="d-flex justify-content-center">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Carregando...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Gráfico de Despesas por Categoria
const ctxDespesas = document.getElementById('despesasPorCategoria');
new Chart(ctxDespesas, {
    type: 'doughnut',
    data: {
        labels: <?php echo json_encode($categorias_labels); ?>,
        datasets: [{
            data: <?php echo json_encode($categorias_valores); ?>,
            backgroundColor: [
                '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF',
                '#FF9F40', '#8AC249', '#EA526F', '#23B5D3', '#7E909A'
            ]
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'right',
            }
        }
    }
});

// Gráfico de Histórico Financeiro
const ctxHistorico = document.getElementById('historicoFinanceiro');
new Chart(ctxHistorico, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($historico_labels); ?>,
        datasets: [
            {
                label: 'Receitas',
                data: <?php echo json_encode($historico_receitas); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            },
            {
                label: 'Despesas',
                data: <?php echo json_encode($historico_despesas); ?>,
                backgroundColor: 'rgba(255, 99, 132, 0.6)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }
        ]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Carregar insights do Gemini
document.addEventListener('DOMContentLoaded', function() {
    // Construir dados para enviar ao Gemini
    const financialData = {
        receita_mensal: <?php echo $receita_mensal; ?>,
        despesa_mensal: <?php echo $despesa_mensal; ?>,
        saldo_mensal: <?php echo $saldo_mensal; ?>,
        categorias: <?php echo json_encode($despesas_por_categoria); ?>,
        historico: <?php echo json_encode($historico_meses); ?>
    };
    
    // Fazer requisição para API Gemini via nosso backend
    fetch('api/gemini.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            action: 'get_insights',
            data: financialData
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('gemini-insights').innerHTML = data.insights;
        } else {
            document.getElementById('gemini-insights').innerHTML = 
                '<div class="alert alert-warning">Não foi possível carregar os insights neste momento.</div>';
        }
    })
    .catch(error => {
        document.getElementById('gemini-insights').innerHTML = 
            '<div class="alert alert-danger">Erro ao carregar insights: ' + error.message + '</div>';
    });
});
</script>

<?php
include 'includes/footer.php';
?>
<script>
function abrirChat() {
    document.getElementById("chat-popup").style.display = "block";
}

function fecharChat() {
    document.getElementById("chat-popup").style.display = "none";
}

async function enviarMensagem() {
    const userText = document.getElementById("chat-input").value;
    document.getElementById("chat-messages").innerHTML += `<p><strong>Você:</strong> ${userText}</p>`;

    const response = await fetch('processar_gemini.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: userText })
    });

    const data = await response.json();
    document.getElementById("chat-messages").innerHTML += `<p><strong>Gemini:</strong> ${data.message}</p>`;
}
</script>

</body>
</html>