<?php
// Página de Transações
$page_title = "Transações";
include 'includes/header.php';

$user_id = $_SESSION['user_id'];

// Inicializa variáveis para filtros
$filtros = [
    'tipo' => $_GET['tipo'] ?? '',
    'categoria_id' => $_GET['categoria_id'] ?? '',
    'data_inicio' => $_GET['data_inicio'] ?? '',
    'data_fim' => $_GET['data_fim'] ?? ''
];

// Define a página atual para paginação
$pagina = isset($_GET['pagina']) ? intval($_GET['pagina']) : 1;
$por_pagina = 10;

// Busca categorias para o formulário
$categorias = get_categories($conn, $user_id);

// Mensagens de sucesso ou erro
$mensagem = '';
$tipo_mensagem = '';

// Excluir transação
if (isset($_GET['excluir']) && !empty($_GET['excluir'])) {
    $id_excluir = intval($_GET['excluir']);
    $sql = "DELETE FROM transacoes WHERE id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_excluir, $user_id);
    
    if ($stmt->execute()) {
        $mensagem = "Transação excluída com sucesso!";
        $tipo_mensagem = "success";
    } else {
        $mensagem = "Erro ao excluir transação: " . $conn->error;
        $tipo_mensagem = "danger";
    }
}

// Adicionar ou editar transação
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $tipo = sanitize($conn, $_POST['tipo']);
    $valor = sanitize($conn, $_POST['valor']);
    $categoria_id = intval($_POST['categoria_id']);
    $data = sanitize($conn, $_POST['data']);
    
    // Valida os campos
    if (empty($tipo) || empty($valor) || empty($data) || empty($categoria_id)) {
        $mensagem = "Todos os campos são obrigatórios!";
        $tipo_mensagem = "danger";
    } else {
        // Formata os dados
        $dados = [
            'id' => $id,
            'tipo' => $tipo,
            'valor' => $valor,
            'categoria_id' => $categoria_id,
            'data' => $data
        ];
        
        // Salva a transação
        if (save_transaction($conn, $dados)) {
            $mensagem = "Transação " . ($id ? "atualizada" : "adicionada") . " com sucesso!";
            $tipo_mensagem = "success";
        } else {
            $mensagem = "Erro ao " . ($id ? "atualizar" : "adicionar") . " transação: " . $conn->error;
            $tipo_mensagem = "danger";
        }
    }
}

// Busca transações com filtros e paginação
$transacoes = get_transactions($conn, $user_id, $pagina, $por_pagina, $filtros);
$total_transacoes = count_transactions($conn, $user_id, $filtros);
$total_paginas = ceil($total_transacoes / $por_pagina);

// Obtém uma transação para edição
$transacao_editar = null;
if (isset($_GET['editar']) && !empty($_GET['editar'])) {
    $id_editar = intval($_GET['editar']);
    $sql = "SELECT * FROM transacoes WHERE id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_editar, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $transacao_editar = $result->fetch_assoc();
    }
}
?>

<div class="container-fluid">
    <?php if (!empty($mensagem)): ?>
        <div class="alert alert-<?php echo $tipo_mensagem; ?> alert-dismissible fade show" role="alert">
            <?php echo $mensagem; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
        </div>
    <?php endif; ?>
    
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <?php echo $transacao_editar ? 'Editar Transação' : 'Nova Transação'; ?>
                    </h5>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <?php if ($transacao_editar): ?>
                            <input type="hidden" name="id" value="<?php echo $transacao_editar['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="tipo" class="form-label">Tipo</label>
                                <select class="form-select" id="tipo" name="tipo" required>
                                    <option value="">Selecione...</option>
                                    <option value="receita" <?php echo ($transacao_editar && $transacao_editar['tipo'] == 'receita') ? 'selected' : ''; ?>>Receita</option>
                                    <option value="despesa" <?php echo ($transacao_editar && $transacao_editar['tipo'] == 'despesa') ? 'selected' : ''; ?>>Despesa</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="valor" class="form-label">Valor</label>
                                <div class="input-group">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control money" id="valor" name="valor" 
                                           value="<?php echo $transacao_editar ? number_format($transacao_editar['valor'], 2, ',', '.') : ''; ?>" 
                                           required>
                                </div>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="categoria_id" class="form-label">Categoria</label>
                                <select class="form-select" id="categoria_id" name="categoria_id" required>
                                    <option value="">Selecione...</option>
                                    <?php foreach ($categorias as $categoria): ?>
                                        <option value="<?php echo $categoria['id']; ?>" 
                                                <?php echo ($transacao_editar && $transacao_editar['categoria_id'] == $categoria['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($categoria['nome']); ?> (<?php echo ucfirst($categoria['tipo']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="data" class="form-label">Data</label>
                                <input type="text" class="form-control datepicker" id="data" name="data" 
                                       value="<?php echo $transacao_editar ? format_date_to_br($transacao_editar['data']) : ''; ?>" 
                                       required>
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <?php if ($transacao_editar): ?>
                                <a href="transactions.php" class="btn btn-secondary me-2">Cancelar</a>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-primary">
                                <?php echo $transacao_editar ? 'Atualizar' : 'Adicionar'; ?>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">Filtros</h5>
                </div>
                <div class="card-body">
                    <form method="get" action="">
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="filtro_tipo" class="form-label">Tipo</label>
                                <select class="form-select" id="filtro_tipo" name="tipo">
                                    <option value="">Todos</option>
                                    <option value="receita" <?php echo ($filtros['tipo'] == 'receita') ? 'selected' : ''; ?>>Receita</option>
                                    <option value="despesa" <?php echo ($filtros['tipo'] == 'despesa') ? 'selected' : ''; ?>>Despesa</option>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="filtro_categoria" class="form-label">Categoria</label>
                                <select class="form-select" id="filtro_categoria" name="categoria_id">
                                    <option value="">Todas</option>
                                    <?php foreach ($categorias as $categoria): ?>
                                        <option value="<?php echo $categoria['id']; ?>" 
                                                <?php echo ($filtros['categoria_id'] == $categoria['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($categoria['nome']); ?> (<?php echo ucfirst($categoria['tipo']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="filtro_data_inicio" class="form-label">Data Início</label>
                                <input type="text" class="form-control datepicker" id="filtro_data_inicio" name="data_inicio" 
                                       value="<?php echo $filtros['data_inicio']; ?>">
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label for="filtro_data_fim" class="form-label">Data Fim</label>
                                <input type="text" class="form-control datepicker" id="filtro_data_fim" name="data_fim" 
                                       value="<?php echo $filtros['data_fim']; ?>">
                            </div>
                        </div>
                        
                        <div class="d-flex justify-content-end">
                            <a href="transactions.php" class="btn btn-secondary me-2">Limpar</a>
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header">
                <h5 class="card-title mb-0">Lista de Transações</h5>
                </div>
                <div class="card-body table-responsive">
                    <table class="table table-bordered table-striped align-middle">
                        <thead>
                            <tr>
                                <th>Tipo</th>
                                <th>Valor</th>
                                <th>Categoria</th>
                                <th>Data</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($transacoes) > 0): ?>
                                <?php foreach ($transacoes as $transacao): ?>
                                    <tr>
                                        <td><?php echo ucfirst($transacao['tipo']); ?></td>
                                        <td>R$ <?php echo number_format($transacao['valor'], 2, ',', '.'); ?></td>
                                        <td><?php echo htmlspecialchars($transacao['categoria_nome']); ?></td>
                                        <td><?php echo format_date_to_br($transacao['data']); ?></td>
                                        <td>
                                            <a href="transactions.php?editar=<?php echo $transacao['id']; ?>" class="btn btn-sm btn-warning me-1">Editar</a>
                                            <a href="transactions.php?excluir=<?php echo $transacao['id']; ?>" class="btn btn-sm btn-danger"
                                               onclick="return confirm('Tem certeza que deseja excluir esta transação?');">Excluir</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nenhuma transação encontrada.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer d-flex justify-content-center">
                    <nav>
                        <ul class="pagination mb-0">
                            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                                <li class="page-item <?php echo ($i == $pagina) ? 'active' : ''; ?>">
                                    <a class="page-link" href="?pagina=<?php echo $i; ?><?php echo http_build_query(array_filter($filtros)); ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
