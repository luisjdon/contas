<?php
// Configurações do banco de dados
$host = 'localhost';
$db_user = 'novosp58_luis';
$db_pass = 'Lh*221620';
$db_name = 'novosp58_sistema_financeiro';

// Conexão com o banco de dados
$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// Verifica conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Configuração para caracteres especiais
$conn->set_charset("utf8");

// Configuração da API Gemini
$gemini_api_key = 'AIzaSyA8ddEupbrglm7N2kjpNCtKimssaWUqKeg';

// Inicia a sessão se ainda não estiver iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Configurações globais
$site_name = "FinControl";
$site_url = "https://novosprogramadores.com/contas"; // Substitua pelo seu domínio na Hostinger