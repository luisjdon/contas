<?php if (is_logged_in() && basename($_SERVER['PHP_SELF']) != 'index.php' && basename($_SERVER['PHP_SELF']) != 'register.php'): ?>
            </div> <!-- Fim do conteúdo principal -->
        </div> <!-- Fim da row flex-nowrap -->
    </div> <!-- Fim do container-fluid -->
<?php else: ?>
    </div> <!-- Fim do container -->
<?php endif; ?>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- Datepicker -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/pt.js"></script>
    
    <!-- Mascaras de input -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="assets/js/script.js"></script>
    
    <footer class="mt-5 text-center text-muted">
        <p>&copy; <?php echo date('Y'); ?> <?php echo $site_name; ?> - Sistema de Controle Financeiro</p>
    </footer>
</body>
</html>