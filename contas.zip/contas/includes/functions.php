<?php
// Funções utilitárias para o sistema

// Formata valor para exibição em reais
function format_currency($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

// Converte data do formato brasileiro para o formato do MySQL
function format_date_to_mysql($date) {
    if (empty($date)) return null;
    $parts = explode('/', $date);
    if (count($parts) == 3) {
        return "$parts[2]-$parts[1]-$parts[0]";
    }
    return $date;
}

// Converte data do formato MySQL para o formato brasileiro
function format_date_to_br($date) {
    if (empty($date)) return '';
    $timestamp = strtotime($date);
    return date('d/m/Y', $timestamp);
}

// Verifica se o usuário está logado
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Redireciona para a página de login se não estiver logado
function require_login() {
    if (!is_logged_in()) {
        header('Location: index.php');
        exit;
    }
}

// Sanitiza inputs para evitar injeção SQL
function sanitize($conn, $input) {
    if (is_array($input)) {
        $output = array();
        foreach ($input as $key => $val) {
            $output[$key] = sanitize($conn, $val);
        }
        return $output;
    } else {
        return mysqli_real_escape_string($conn, trim($input));
    }
}

// Gera um alerta em HTML
function alert($message, $type = 'info') {
    return '<div class="alert alert-' . $type . ' alert-dismissible fade show" role="alert">
                ' . $message . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
            </div>';
}

// Obtém o total de receitas do mês para um usuário
// Se $month_year for null, usa o mês atual
function get_month_revenue($conn, $user_id, $month_year = null) {
    if ($month_year === null) {
        $month_year = date('Y-m');
    }
    
    $first_day = $month_year . '-01';
    $last_day = date('Y-m-t', strtotime($first_day));
    
    $sql = "SELECT SUM(valor) as total FROM transacoes 
            WHERE usuario_id = ? 
            AND tipo = 'receita' 
            AND data BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $first_day, $last_day);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['total'] ?? 0;
}

// Obtém o total de despesas do mês para um usuário
// Se $month_year for null, usa o mês atual
function get_month_expenses($conn, $user_id, $month_year = null) {
    if ($month_year === null) {
        $month_year = date('Y-m');
    }
    
    $first_day = $month_year . '-01';
    $last_day = date('Y-m-t', strtotime($first_day));
    
    $sql = "SELECT SUM(valor) as total FROM transacoes 
            WHERE usuario_id = ? 
            AND tipo = 'despesa' 
            AND data BETWEEN ? AND ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $first_day, $last_day);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['total'] ?? 0;
}

// Obtém o saldo atual (receitas - despesas) do mês para um usuário
// Se $month_year for null, usa o mês atual
function get_current_balance($conn, $user_id, $month_year = null) {
    $revenues = get_month_revenue($conn, $user_id, $month_year);
    $expenses = get_month_expenses($conn, $user_id, $month_year);
    return $revenues - $expenses;
}

// Obtém todas as categorias disponíveis para um usuário
function get_categories($conn, $user_id, $type = null) {
    $sql = "SELECT * FROM categorias WHERE 1=1";
    $params = [];
    $types = "";
    
    if ($type) {
        $sql .= " AND tipo = ?";
        $params[] = $type;
        $types .= "s";
    }
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $categories = [];
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
    
    return $categories;
}

// Salva ou atualiza uma transação
function save_transaction($conn, $data) {
    $user_id = $_SESSION['user_id'];
    $tipo = $data['tipo'];
    $valor = str_replace(['R$', '.', ','], ['', '', '.'], $data['valor']);
    $categoria_id = $data['categoria_id'];
    $data_transacao = format_date_to_mysql($data['data']);
    
    if (isset($data['id']) && !empty($data['id'])) {
        // Atualizar transação existente
        $sql = "UPDATE transacoes SET tipo = ?, valor = ?, categoria_id = ?, data = ? 
                WHERE id = ? AND usuario_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdisii", $tipo, $valor, $categoria_id, $data_transacao, $data['id'], $user_id);
    } else {
        // Inserir nova transação
        $sql = "INSERT INTO transacoes (tipo, valor, categoria_id, data, usuario_id) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdisi", $tipo, $valor, $categoria_id, $data_transacao, $user_id);
    }
    
    return $stmt->execute();
}

// Obtém dados para o relatório mensal
function get_monthly_report($conn, $user_id, $month) {
    // Verifica se já existe relatório para o mês
    $sql = "SELECT * FROM relatorios WHERE usuario_id = ? AND mes = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $month);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Retorna o relatório existente
        return $result->fetch_assoc();
    } else {
        // Gera novo relatório
        $first_day = $month . "-01";
        $last_day = date('Y-m-t', strtotime($first_day));
        
        // Calcular receitas
        $sql = "SELECT SUM(valor) as total FROM transacoes 
                WHERE usuario_id = ? 
                AND tipo = 'receita' 
                AND data BETWEEN ? AND ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $first_day, $last_day);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $receitas = $row['total'] ?? 0;
        
        // Calcular despesas
        $sql = "SELECT SUM(valor) as total FROM transacoes 
                WHERE usuario_id = ? 
                AND tipo = 'despesa' 
                AND data BETWEEN ? AND ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $first_day, $last_day);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $despesas = $row['total'] ?? 0;
        
        // Calcular saldo
        $saldo = $receitas - $despesas;
        
        // Salvar relatório
        $sql = "INSERT INTO relatorios (usuario_id, mes, saldo, despesas, receitas) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("isddd", $user_id, $month, $saldo, $despesas, $receitas);
        $stmt->execute();
        
        // Retornar dados do relatório
        return [
            'usuario_id' => $user_id,
            'mes' => $month,
            'saldo' => $saldo,
            'despesas' => $despesas,
            'receitas' => $receitas
        ];
    }
}

// Obtém as transações do usuário com paginação
function get_transactions($conn, $user_id, $page = 1, $limit = 10, $filters = []) {
    $offset = ($page - 1) * $limit;
    
    $sql = "SELECT t.*, c.nome as categoria_nome 
            FROM transacoes t 
            LEFT JOIN categorias c ON t.categoria_id = c.id 
            WHERE t.usuario_id = ?";
    
    $params = [$user_id];
    $types = "i";
    
    // Aplicar filtros
    if (!empty($filters['tipo'])) {
        $sql .= " AND t.tipo = ?";
        $params[] = $filters['tipo'];
        $types .= "s";
    }
    
    if (!empty($filters['data_inicio'])) {
        $sql .= " AND t.data >= ?";
        $params[] = format_date_to_mysql($filters['data_inicio']);
        $types .= "s";
    }
    
    if (!empty($filters['data_fim'])) {
        $sql .= " AND t.data <= ?";
        $params[] = format_date_to_mysql($filters['data_fim']);
        $types .= "s";
    }
    
    if (!empty($filters['categoria_id'])) {
        $sql .= " AND t.categoria_id = ?";
        $params[] = $filters['categoria_id'];
        $types .= "i";
    }
    
    $sql .= " ORDER BY t.data DESC LIMIT ?, ?";
    $params[] = $offset;
    $params[] = $limit;
    $types .= "ii";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $transactions = [];
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    
    return $transactions;
}

// Conta o total de transações para paginação
function count_transactions($conn, $user_id, $filters = []) {
    $sql = "SELECT COUNT(*) as total FROM transacoes WHERE usuario_id = ?";
    
    $params = [$user_id];
    $types = "i";
    
    // Aplicar filtros
    if (!empty($filters['tipo'])) {
        $sql .= " AND tipo = ?";
        $params[] = $filters['tipo'];
        $types .= "s";
    }
    
    if (!empty($filters['data_inicio'])) {
        $sql .= " AND data >= ?";
        $params[] = format_date_to_mysql($filters['data_inicio']);
        $types .= "s";
    }
    
    if (!empty($filters['data_fim'])) {
        $sql .= " AND data <= ?";
        $params[] = format_date_to_mysql($filters['data_fim']);
        $types .= "s";
    }
    
    if (!empty($filters['categoria_id'])) {
        $sql .= " AND categoria_id = ?";
        $params[] = $filters['categoria_id'];
        $types .= "i";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['total'];
}