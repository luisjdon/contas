<?php
// Inclui configurações e funções
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Verifica se usuário está logado, exceto na página de login e registro
$current_page = basename($_SERVER['PHP_SELF']);
if ($current_page != 'index.php' && $current_page != 'register.php') {
    require_login();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . $site_name : $site_name; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Datepicker -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php if (is_logged_in() && $current_page != 'index.php' && $current_page != 'register.php'): ?>
    <div class="container-fluid">
        <div class="row flex-nowrap">
            <!-- Sidebar incluído apenas se usuário estiver logado -->
            <?php include 'includes/sidebar.php'; ?>
            
            <!-- Conteúdo principal -->
            <div class="col py-3">
                <header class="mb-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <h1><?php echo $page_title ?? $site_name; ?></h1>
                        <div class="dropdown">
                            <button class="btn btn-outline-primary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-1"></i> <?php echo htmlspecialchars($_SESSION['user_name']); ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="profile.php"><i class="fas fa-id-card me-2"></i>Perfil</a></li>
                                <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cog me-2"></i>Configurações</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </header>
<?php else: ?>
    <div class="container">
<?php endif; ?>