<?php
// Funções relacionadas à autenticação

// Função para registrar um novo usuário
function register_user($conn, $nome, $email, $senha) {
    // Verifica se o email já está cadastrado
    $sql = "SELECT id FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'Este email já está cadastrado.'
        ];
    }
    
    // Hash da senha
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
    
    // Insere o novo usuário
    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $email, $senha_hash);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Cadastro realizado com sucesso!'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Erro ao cadastrar: ' . $conn->error
        ];
    }
}

// Função para autenticar um usuário
function login_user($conn, $email, $senha) {
    $sql = "SELECT id, nome, email, senha FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return [
            'success' => false,
            'message' => 'Email não cadastrado.'
        ];
    }
    
    $usuario = $result->fetch_assoc();
    
    // Verifica a senha
    if (password_verify($senha, $usuario['senha'])) {
        // Senha correta, inicia a sessão
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['user_name'] = $usuario['nome'];
        $_SESSION['user_email'] = $usuario['email'];
        
        return [
            'success' => true,
            'message' => 'Login realizado com sucesso!'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Senha incorreta.'
        ];
    }
}

// Função para fazer logout
function logout_user() {
    // Remove todas as variáveis de sessão
    $_SESSION = array();
    
    // Destrói a sessão
    session_destroy();
    
    // Redireciona para a página inicial
    header("Location: index.php");
    exit;
}

// Função para atualizar senha do usuário
function update_password($conn, $user_id, $current_password, $new_password) {
    // Verifica a senha atual
    $sql = "SELECT senha FROM usuarios WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();
    
    if (!password_verify($current_password, $usuario['senha'])) {
        return [
            'success' => false,
            'message' => 'Senha atual incorreta.'
        ];
    }
    
    // Atualiza a senha
    $senha_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $sql = "UPDATE usuarios SET senha = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $senha_hash, $user_id);
    
    if ($stmt->execute()) {
        return [
            'success' => true,
            'message' => 'Senha atualizada com sucesso!'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Erro ao atualizar senha: ' . $conn->error
        ];
    }
}

// Função para atualizar informações do perfil
function update_profile($conn, $user_id, $nome, $email) {
    // Verifica se o email já existe para outro usuário
    $sql = "SELECT id FROM usuarios WHERE email = ? AND id != ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $email, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return [
            'success' => false,
            'message' => 'Este email já está sendo usado por outro usuário.'
        ];
    }
    
    // Atualiza o perfil
    $sql = "UPDATE usuarios SET nome = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nome, $email, $user_id);
    
    if ($stmt->execute()) {
        // Atualiza os dados da sessão
        $_SESSION['user_name'] = $nome;
        $_SESSION['user_email'] = $email;
        
        return [
            'success' => true,
            'message' => 'Perfil atualizado com sucesso!'
        ];
    } else {
        return [
            'success' => false,
            'message' => 'Erro ao atualizar perfil: ' . $conn->error
        ];
    }
}