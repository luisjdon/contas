<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);
include 'includes/auth.php';
include 'includes/config.php'; // Garante que a conexão com o banco de dados esteja configurada corretamente
include 'includes/header.php';

// Lidar com envio de formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $tipo = $_POST['tipo'];

    // Usando a variável $conn corretamente para inserir os dados
    $stmt = $conn->prepare("INSERT INTO categorias (nome, tipo) VALUES (?, ?)");
    if (!$stmt) {
        die("Erro na preparação da consulta: " . $conn->error);
    }
    
    $stmt->bind_param('ss', $nome, $tipo);
    $stmt->execute();
    $stmt->close();

    header("Location: categories.php");
    exit;
}

// Obter categorias existentes usando a conexão $conn
$result = $conn->query("SELECT * FROM categorias ORDER BY tipo, nome");
if (!$result) {
    die("Erro ao obter categorias: " . $conn->error);
}
$categorias = $result->fetch_all(MYSQLI_ASSOC);
?>

<style>
    .form-container {
        position: sticky;
        top: 20px;
        background: #fff;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    .category-list {
        margin-top: 20px;
    }
</style>

<div class="container mt-4">
    <div class="form-container">
        <h2>Categorias</h2>
        <form method="POST" class="mb-4">
            <div class="form-row">
                <div class="col">
                    <input type="text" name="nome" class="form-control" placeholder="Nome da Categoria" required>
                </div>
                <div class="col">
                    <select name="tipo" class="form-control" required>
                        <option value="receita">Receita</option>
                        <option value="despesa">Despesa</option>
                    </select>
                </div>
                <div class="col">
                    <button class="btn btn-primary">Adicionar</button>
                </div>
            </div>
        </form>
    </div>

    <div class="category-list">
        <ul class="list-group">
            <?php foreach ($categorias as $cat): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?= htmlspecialchars($cat['nome']) ?>
                    <span class="badge badge-<?= $cat['tipo'] == 'receita' ? 'success' : 'danger' ?>">
                        <?= ucfirst($cat['tipo']) ?>
                    </span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<?php
include 'includes/footer.php';
?>