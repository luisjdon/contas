<?php
require_once 'includes/config.php';
header('Content-Type: application/json');
session_start();

$json = file_get_contents("php://input");
$input = json_decode($json, true);

if (!isset($input['text'])) {
    echo json_encode(['success' => false, 'message' => 'Nenhuma mensagem foi recebida.']);
    exit;
}

// 🔹 Chave da API Gemini
$api_key = "AIzaSyAhtSTUL7Rz5ex1D_fEA6Gg77FiiBOdQDw"; // Substitua pela sua chave válida

// 🔹 Construção do prompt para a IA
$prompt = "Interprete a seguinte mensagem financeira e extraia os dados necessários para registrar uma transação.
Mensagem: '{$input['text']}'

🔹 Extraia:
- Tipo da transação: 'receita' ou 'despesa'.
- O valor corretamente, reconhecendo formatos como: '15 reais', 'R$15,00', 'quinze reais', '0,50 centavos'.
- Ajuste a categoria automaticamente com base em palavras-chave comuns (exemplo: 'eletrônicos' deve ser 'Compras').

Responda **APENAS** no formato JSON abaixo, sem explicações:
{
  \"tipo\": \"despesa\",
  \"valor\": 15.00,
  \"categoria\": \"Compras\"
}

Se a mensagem for inválida ou não puder ser interpretada, retorne:
{
  \"erro\": \"Não foi possível interpretar a transação.\"
}";

// 🔹 Envio da requisição para Gemini
$payload = ["contents" => [["parts" => [["text" => $prompt]]]]];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $api_key);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

// 🔹 Log para verificar a resposta da IA
error_log("Resposta do Gemini: " . print_r($result, true));

// 🔹 Verificar resposta da IA
if (!isset($result['candidates'][0]['content']['parts'][0]['text'])) {
    echo json_encode(['success' => false, 'message' => 'Erro ao obter resposta da IA.']);
    exit;
}

// 🔹 Remover crases do JSON retornado antes de decodificá-lo
$response_text = $result['candidates'][0]['content']['parts'][0]['text'];
$response_text = trim($response_text);
$response_text = preg_replace('/^```json/', '', $response_text);
$response_text = preg_replace('/```$/', '', $response_text);

$gemini_response = json_decode($response_text, true);

// 🔹 Se a IA não conseguir interpretar os dados
if (!is_array($gemini_response) || !isset($gemini_response['tipo']) || !isset($gemini_response['valor']) || !isset($gemini_response['categoria'])) {
    echo json_encode(['success' => false, 'message' => 'Erro: A IA retornou um formato inválido.']);
    exit;
}

// 🔹 Criar categoria automaticamente se não existir
$categoria = $gemini_response['categoria'];
$sql_categoria = "SELECT id FROM categorias WHERE nome = ? LIMIT 1";
$stmt_categoria = $conn->prepare($sql_categoria);
$stmt_categoria->bind_param("s", $categoria);
$stmt_categoria->execute();
$result_categoria = $stmt_categoria->get_result();

if ($result_categoria->num_rows === 0) {
    // 🔸 Criar nova categoria
    $tipo_categoria = ($gemini_response['tipo'] === "receita") ? "receita" : "despesa";
    $sql_insert_categoria = "INSERT INTO categorias (nome, tipo) VALUES (?, ?)";
    $stmt_insert_categoria = $conn->prepare($sql_insert_categoria);
    $stmt_insert_categoria->bind_param("ss", $categoria, $tipo_categoria);
    $stmt_insert_categoria->execute();
}

// 🔹 Registrar transação no banco de dados
$sql_transacao = "INSERT INTO transacoes (tipo, valor, categoria_id, data, usuario_id, descricao) 
                  VALUES (?, ?, (SELECT id FROM categorias WHERE nome = ? LIMIT 1), NOW(), ?, ?)";
$stmt_transacao = $conn->prepare($sql_transacao);
$stmt_transacao->bind_param("sdssi", $gemini_response['tipo'], $gemini_response['valor'], $categoria, $_SESSION['user_id'], $input['text']);
$stmt_transacao->execute();

echo json_encode(['success' => true, 'message' => 'Transação registrada com sucesso!']);
?>