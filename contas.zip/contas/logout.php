<?php
// Página para logout do usuário
session_start();

// Destruir a sessão
session_unset();
session_destroy();

// Redirecionar para a página inicial
header('Location: index.php');
exit;
