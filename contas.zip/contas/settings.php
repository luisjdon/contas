<?php
$page_title = "Configurações";
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">Configurações da Conta</h5>
                </div>
                <div class="card-body">
                    <p>Aqui futuramente você poderá alterar sua senha, email ou preferências.</p>
                    <a href="profile.php" class="btn btn-primary">Ver Perfil</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
